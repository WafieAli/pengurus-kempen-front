// This is the secret phrase used in JWT creation
module.exports = {
  secret: "er6j75k&^54(5j64h53yg$t2@H6j75^H!%$65#BY42vT3"
};
