exports.userHome = (req, res) => {
  res.status(200).send("User home page");
};
exports.userProfile = (req, res) => {
  res.status(200).send("User Profile");
};
