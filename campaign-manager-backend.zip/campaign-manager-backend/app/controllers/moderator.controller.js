exports.moderatorHome = (req, res) => {
    res.status(200).send("Moderator home page");
  };
exports.moderatorProfile = (req, res) => {
    res.status(200).send("Moderator Profile");
  };
  
