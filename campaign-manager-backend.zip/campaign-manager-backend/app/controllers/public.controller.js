exports.publicHome = (req, res) => {
    res.status(200).send("Welcome To SmartRetail Home Page ...");
  };
  
